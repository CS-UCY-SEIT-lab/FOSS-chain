#include <stdio.h>
#include "utils.c"

void greet() {
    printf("Hello, Derived World!\n");
}

int main() {
    greet();

    char str[] = "Derived Project";
    printf("Original: %s\n", str);
    reverse_string(str);
    printf("Reversed: %s\n", str);

    return 0;
}
